import java.awt.*;
import java.awt.event.*;
import java.util.Scanner;

public class P1_Sun_Meilinda_MinesweeperController
       implements ActionListener  {
    Scanner in = new Scanner(System.in);
    P1_Sun_Meilinda_MinesweeperModel myModel;
    P1_Sun_Meilinda_MinesweeperView myView;
    
    public P1_Sun_Meilinda_MinesweeperController()  {
        myModel = new P1_Sun_Meilinda_MinesweeperModel();
        myView = new P1_Sun_Meilinda_MinesweeperView(myModel, this);
    }
    
    void newGame()  {
        myModel = new P1_Sun_Meilinda_MinesweeperModel();
        myView.numMines.setText("" + myModel.getMinesLeft());
        myView.newGame(myModel);
    }
    
    public void actionPerformed(ActionEvent e)  {
        String rep = e.getActionCommand();
        if (rep.equals("New Game"))  {
            newGame();
        }
        else if (rep.equals("Exit"))  {
            System.exit(0);
        }
        else if (rep.equals("How to Play"))  {
            myView.howToPlay();
        }
        else if (rep.equals("About"))  {
            myView.about();
        }
        else if (rep.equals("Set Number of Mines"))  {
            int numMines = myView.setNumMines(myModel.getMineNum());
            myModel.setMineNum(numMines);
        }
    }
}