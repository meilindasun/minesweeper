/* Meilinda Sun, P1, 3/11/16
 * Time Taken: 14 Hours
 * 
 * The most challenging part of the lab was making sure
 * all of the "links" worked. I not only had to link 
 * each object to its respective listener, but also
 * link the controller, view, and model together so that
 * everything worked in tandem. For example, even if I
 * updated a variable in model, it often didn't show up
 * because I failed to reference the update in my view 
 * function. Therefore, to debug such a complicated mass
 * of code I resorted to printing information to see 
 * whether a particular function was really accessed or not
 * which would help me determine whether the link I had
 * attempted actually worked. In doing so, I was able to
 * identify parts of my code that didn't work and repair
 * it based on the information printed to me.
 */
public class P1_Sun_Meilinda_MinesweeperDriver
{
    public static void main(String[] args)  {
        P1_Sun_Meilinda_MinesweeperController myController = new P1_Sun_Meilinda_MinesweeperController();
        myController.myModel.fillMine();
    }
}
