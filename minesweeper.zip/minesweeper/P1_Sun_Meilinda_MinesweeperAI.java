import java.util.Random;
public class P1_Sun_Meilinda_MinesweeperAI  {
    
    P1_Sun_Meilinda_MinesweeperModel myModel;
    final char COVERED = '-';
    final char REVEAL = 'R';
    final int THRESHOLD = 20;
    final char MINE = '*';
    final char FLAG = 'F';
    final int FLAGTHRESHOLD = 3;
    final static char NOMOVE = 'N';
    int yLen, xLen;
    char[][] myGridShown;
    char[][] myGridActual;
    public static final int[] yInc = {0, -1, -1, -1, 0, 1, 1, 1, 0};
    public static final int[] xInc = {0, -1, 0, 1, 1, 1, 0, -1, -1};
    
    public P1_Sun_Meilinda_MinesweeperAI(P1_Sun_Meilinda_MinesweeperModel model)  {
        myModel = model;
        yLen = myModel.getYLen();
        xLen = myModel.getXLen();
        myGridShown = myModel.getGridShown();
        myGridActual = myModel.getGridActual();
    }
    
    public class Move  {
        int myY, myX;
        char myAction;
        public Move(int y, int x, char action)  {
            myY = y;
            myX = x;
            myAction = action;
        }
        
        public void reset (int y, int x, char action)  {
            myY = y;
            myX = x;
            myAction = action;
        }
    }
    
    private int numC()  {
        int numCovered = 0;
        for (int i = 0; i < yLen; i++)  {
            for (int j = 0; j < xLen; j++)  {
                if (myGridShown[i][j] == COVERED)  {
                    numCovered++;
                }
            }
        }
        return numCovered;
    }
    
    private int percentRevealed()  {
        return (numC() / (yLen * xLen)) * 100;
    }
    
    private Move pickRandom()  {
       int n = numC();
       if (n <= 0)  {
           return null;
       }
       Random r = new Random();
       int valIndex = (int)(r.nextInt(n));
       int numCovered = 0;
       for (int i = 0; i < yLen; i++)  {
           for (int j = 0; j < xLen; j++)  {
               if (myGridShown[i][j] == COVERED)  {
                    numCovered++;
                    if (numCovered == valIndex)  {
                        return new Move(i, j, REVEAL);
                    }
               }
           }
       }
       return null;
    }
    
    boolean eligible (int y, int x)  {
        if (y < 0 || y >= yLen || x < 0 || x >= xLen)  {
            return false;
        }
System.out.println("myGridActual[" + y + "][" + x + "] = " + myGridActual[y][x]);
        int neighbors = Integer.parseInt("" + myGridActual[y][x]);
        if (neighbors >= 0 && neighbors <= 8 
                || myGridActual[y][x] == MINE)  {
            return true;
        }
        return false;
    }
    
    private Move rank ()  {
        int lowestScore = 100;
        Move lowestMove = new Move(-1, -1, NOMOVE$);
        int highestScore = 100000;
        Move highestMove = new Move(-1, -1, NOMOVE);
        for (int i = 0; i < yLen; i++)  {
            for (int j = 0; j < xLen; j++)  {
                int currScore = 0;
                for (int k = 0; k < yInc.length; k++)  {
                    int newY = i + yInc[k];
                    int newX = j + xInc[k];
                    if (eligible(newY, newX))  {
                        currScore += Integer.parseInt(
                            "" + myGridActual[newY][newX]);
                    }
                }
                if (currScore < lowestScore)  {
                    lowestScore = currScore;
                    lowestMove.reset(i, j, FLAG);
                }
                if (currScore > highestScore)  {
                    highestScore = currScore;
                    highestMove.reset(i, j, REVEAL);
                }
            }
        }
        if (lowestMove.myAction == NOMOVE && highestMove.myAction == NOMOVE)  {
            return null;
        }
        if (lowestMove.myAction == NOMOVE)  {
            return highestMove;
        }
        if (highestMove.myAction == NOMOVE)  {
            return lowestMove;
        }
        if (lowestScore <= FLAGTHRESHOLD)  {
            return lowestMove;
        }
        else  {
            return highestMove;
        }
    }
    
    public Move getNextMove()  {
        int percent = percentRevealed();
        if (percent <= THRESHOLD)  {
            return pickRandom();
        }
        else  {
            return rank();
        }        
    }
}